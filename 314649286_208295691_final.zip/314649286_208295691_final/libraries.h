#ifndef TEC_PROJECT_3_LIBRARIES_H
#define TEC_PROJECT_3_LIBRARIES_H

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <math.h>

#endif
