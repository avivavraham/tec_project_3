#ifndef TEC_PROJECT_3_SPKMEANS_H
#define TEC_PROJECT_3_SPKMEANS_H

#include "nsclustering.h"

#endif
